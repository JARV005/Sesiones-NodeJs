import express,{Router} from 'express';

const PORT=3000;

const app = express();

//middleware= se ejecuta antes de cada ruta.
app.use(express.json());

//Middleware personalizado= Imprime el método y la URL de cada solicitud.
app.use((req,res,next)=>{
    console.log(`${req.method} ${req.url}`);
    next();
})


let libros = [
    {id:1, titulo:'El Quijote', autor:'Miguel de Cervantes'},
    {id:2, titulo:'Cien Años de Soledad', autor:'Gabriel García Márquez'},
    {id:3, titulo:'La Sombra del Viento', autor:'Carlos Ruiz Zafón'}
]

let siguienteId = 4;

const librosRouter = Router();

//obtener todos los libros

librosRouter.get('/',(req,res)=>{
    res.json(libros);
})

// obtener un libro por ID
librosRouter.get('/:id',(req,res)=>{
    const id = Number(req.params.id);
    const libro = libros.find(lib => lib.id === id);

    if(!libro){
        return res.status(404).json({error:'Libro no encontrado'});
    }
    res.json(libro);
})

// agregar un nuevo libro
librosRouter.post('/',(req,res)=>{
    const {titulo, autor}= req.body;

    if(!titulo || !autor){
        return res.status(400).json({error:'Faltan campos obligatorios'});
    }

    const nuevoLibro = {
        id: siguienteId++,
        titulo,
        autor
    };

    libros.push(nuevoLibro);
    res.status(201).json(nuevoLibro);
})


//actualizar un libro 
librosRouter.put('/:id',(req,res)=>{
    const id = Number(req.params.id);
    const libro = libros.find(lib => lib.id === id);

    if(!libro){
        return res.status(404).json({error:'Libro no encontrado'});
    }

    const {titulo,autor}= req.body;
    if(titulo !== undefined) libro.titulo = titulo; 
    if(autor !== undefined) libro.autor = autor;

    res.json(libro);
})

//borrar un libro
librosRouter.delete('/:id',(req,res)=>{
    const id = Number(req.params.id);
    const indice= libros.findIndex(lib => lib.id === id);

    if(indice === -1){
        return res.status(404).json({error:'Libro no encontrado'});
    }

    libros.splice(indice, 1);
    res.json({message:'Libro eliminado'});
})

app.use('/libros', librosRouter);


app.listen(PORT, ()=>{
    console.log(`Server running on port ${PORT}`);
})


